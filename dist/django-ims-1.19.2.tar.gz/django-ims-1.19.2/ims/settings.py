import os
# IMS app settings
APP_DIR = os.path.dirname(os.path.abspath(__file__))
PAGE_SIZE = 20