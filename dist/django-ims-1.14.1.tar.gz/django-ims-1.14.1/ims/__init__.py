#VERSION='1.11.0'
#VERSION='1.11.1'
#VERSION=('1.12.0','10/11/2015','allow auto generation of product codes. Add date and comments to version')
#VERSION=('1.12.1','12/11/2015','fix generate code button and templates that use it')
#VERSION=('1.13.0','12/11/2015','make product code 36 char and auto generate uuid4 compliant codes in js')
#VERSION=('1.14.0','15/11/2015','updates to ProductCode and Category, mostly UI improvements')
VERSION=('1.14.1','15/11/2015','left justify category and code in products list')